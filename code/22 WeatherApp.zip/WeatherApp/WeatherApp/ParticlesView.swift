//
//  ParticlesView.swift
//  WeatherApp
//
//  Created by Ivan Akulov on 02/09/16.
//  Copyright © 2016 Ivan Akulov. All rights reserved.
//

import UIKit
import SpriteKit

class ParticlesView: SKView {

}
