//
//  APIManager.swift
//  WeatherApp
//
//  Created by Ivan Akulov on 30/08/16.
//  Copyright © 2016 Ivan Akulov. All rights reserved.
//

import Foundation

typealias JSONTask = URLSessionDataTask
typealias JSONCompletionHandler = ([String: AnyObject]?, HTTPURLResponse?, Error?) -> Void

protocol APIManager {
  var sessionConfiguration: URLSessionConfiguration { get }
  var session: URLSession { get }
  
  func JSONTaskWith(request: URLRequest, completionHandler: JSONCompletionHandler) -> JSONTask
  
  init(sessionConfiguration: URLSessionConfiguration)
}
